# ANDRITZ Dev Assessment

This is a evaluation test for developer position.

There are 2 tests:

1: Imagine that we have a subtitle file (.srt) out of sync. The program must be able to shift the whole source file by the given timespan.

2: Given a predefined list of links, the program must be able to calculate the possible paths between one point and another.
